package com.example.alejandro_rodriguezblas_uf1_act12

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.ToggleButton

class MainActivity : AppCompatActivity() {

    lateinit var toggle : ToggleButton
    lateinit var scroll : HorizontalScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        toggle = findViewById(R.id.Toggle)
        scroll = findViewById(R.id.horizontalScrollView)

        toggle.setOnCheckedChangeListener{ _, isChecked ->
            if(isChecked){
                scroll.isVerticalScrollBarEnabled = false
            }
            else{
                scroll.isHorizontalScrollBarEnabled = true
            }
        }
    }
}